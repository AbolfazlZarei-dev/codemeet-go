package main

import (
	"context"
	"fmt"
	"io"
	"os"
	"os/signal"
	"syscall"
	"time"

	codemeet "github.com/AbolfazlZarei-dev/codemeet-go/codemeet"
	"github.com/AbolfazlZarei-dev/codemeet-go/contrib/vpndetector"
	"github.com/AbolfazlZarei-dev/codemeet-go/logger"
	"github.com/AbolfazlZarei-dev/codemeet-go/middleware"
	"github.com/AbolfazlZarei-dev/codemeet-go/models"
	"github.com/AbolfazlZarei-dev/codemeet-go/polling"
)

func main() {
	token := os.Getenv("CODEMEET_BOT_TOKEN")
	if token == "" {
		token = "c8b78625bcf7:9KxPYCw4OYK_u56nz1K6ufCIPXDWcIxDXff01c2TvFc"
	}

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	appLogger := logger.New(logger.LevelInfo)
	appLogger.SetIncludeCaller(true)

	var bot *codemeet.Bot

	// --- پیکربندی تشخیص VPN ---
	vpnCfg := vpndetector.DefaultConfig()

	// تابع دانلود فایل از سرور کدمیت
	// این تابع باید فایل را به صورت io.ReadCloser برگرداند
	vpnCfg.DownloadAction = func(ctx context.Context, fileID string) (io.ReadCloser, error) {
		// ۱. دریافت اطلاعات فایل (برای به دست آوردن FilePath)
		file, err := bot.API().Media().GetFile(ctx, fileID)
		if err != nil {
			return nil, err
		}

		// ۲. دانلود مستقیم فایل از سرور کدمیت به صورت استریم
		return bot.API().Client().DownloadFile(ctx, file.FilePath)
	}

	// اکشن هنگام شناسایی VPN یا کانفیگ
	vpnCfg.Action = func(ctx context.Context, userID, chatID string, messageID int, reason string) {
		// ۱. پاک کردن پیام کاربر (فایل یا متن)
		_ = bot.API().Messages().Delete(ctx, chatID, messageID)

		// ۲. اخطار به کاربر
		warnText := fmt.Sprintf("🚫 ارسال برنامه VPN، کانفیگ یا لینک‌های دور زدن تحریم در این گروه ممنوع است!\n\n دلیل: %s", reason)
		_, _ = bot.Send(ctx, chatID, warnText)

		// ۳. لاگ دقیق در ترمینال و داشبورد
		appLogger.Warn("VPN/Proxy Detected!", "user", userID, "reason", reason)
	}

	vpnDetectorInstance := vpndetector.New(vpnCfg)

	// --- ساخت ربات ---
	var err error
	bot, err = codemeet.New(token,
		codemeet.WithLogger(appLogger),
		codemeet.WithShardedCache(32, 10*time.Minute),
		codemeet.WithRateLimit(25),
	)
	if err != nil {
		appLogger.Fatal("Failed to create bot", "error", err)
	}

	// --- ثبت Middleware ها ---
	bot.Use(
		middleware.Recovery(appLogger),
		middleware.Logging(appLogger),
		vpnDetectorInstance.VPNDetectorMiddleware(), // تشخیص VPN
	)

	// --- هندلرها ---
	bot.OnCommand("start", func(ctx context.Context, msg *models.Message) {
		_, _ = bot.SendHTML(ctx, msg.Chat.ID, "سلام! ربات فعال است.\nبرای تست:\n۱. یک متن شامل کلمه vpn بفرستید.\n۲. یک فایل با پسوند apk بفرستید.\n۳. یک فایل متنی حاوی کانفیگ vmess بفرستید.")
	})

	// اگر پیام مشکلی نداشت، آن را تایید کن
	bot.OnMessage(func(ctx context.Context, msg *models.Message) {
		_, _ = bot.Send(ctx, msg.Chat.ID, "✅ پیام شما امن است.")
	})

	// --- راه‌اندازی داشبورد و Polling ---
	go func() {
		appLogger.Info("Starting Web Dashboard on http://localhost:8081")
		if err := bot.StartDashboard(ctx, ":8081"); err != nil {
			appLogger.Error("Dashboard failed", "error", err)
		}
	}()

	pollingCfg := polling.DefaultConfig()
	pollingCfg.Timeout = 20

	appLogger.Info("Bot is starting polling...")
	if err := bot.StartPolling(ctx, pollingCfg); err != nil && err != context.Canceled {
		appLogger.Error("Bot stopped with error", "error", err)
	}

	appLogger.Info("Shutting down bot gracefully...")
	if err := bot.Close(); err != nil {
		appLogger.Error("Error during bot close", "error", err)
	}
}
