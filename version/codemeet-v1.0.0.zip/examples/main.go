package main

import (
    "context"
    "fmt"
    "os"
    "os/signal"
    "syscall"
    "time"

    codemeet "github.com/AbolfazlZarei-dev/codemeet-go/codemeet"
    "github.com/AbolfazlZarei-dev/codemeet-go/contrib/profanityfilter"
    "github.com/AbolfazlZarei-dev/codemeet-go/logger"
    "github.com/AbolfazlZarei-dev/codemeet-go/middleware"
    "github.com/AbolfazlZarei-dev/codemeet-go/models"
    "github.com/AbolfazlZarei-dev/codemeet-go/polling"
)

func main() {
    token := os.Getenv("CODEMEET_BOT_TOKEN")
    if token == "" {
        token = "c8b78625bcf7:9KxPYCw4OYK_u56nz1K6ufCIPXDWcIxDXff01c2TvFc"
    }

    ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
    defer stop()

    appLogger := logger.New(logger.LevelInfo)
    appLogger.SetIncludeCaller(true)

    var bot *codemeet.Bot

    // --- پیکربندی فیلتر کلمات ---
    profanityCfg := profanityfilter.DefaultConfig()
    // کلمات ممنوعه را تنظیم می‌کنیم
    profanityCfg.BannedWords = []string{"fuck", "idiot", "spam"}
    
    // اکشن هنگام شناسایی کلمه ممنوعه
    profanityCfg.Action = func(ctx context.Context, userID, chatID string, messageID int, reason string) {
        // ۱. پاک کردن پیام کاربر
        _ = bot.API().Messages().Delete(ctx, chatID, messageID)
        
        // ۲. ارسال اخطار به کاربر
        warnText := fmt.Sprintf("🚫 پیام شما به دلیل استفاده از کلمات نامناسب پاک شد!\nدلیل: %s", reason)
        _, _ = bot.Send(ctx, chatID, warnText)
        
        // ۳. لاگ کردن در ترمینال
        appLogger.Warn("Profanity Detected!", "user", userID, "reason", reason)
    }

    profanityInstance := profanityfilter.New(profanityCfg)

    // --- ساخت ربات ---
    var err error
    bot, err = codemeet.New(token,
        codemeet.WithLogger(appLogger),
        codemeet.WithShardedCache(32, 10*time.Minute),
        codemeet.WithRateLimit(25),
    )
    if err != nil {
        appLogger.Fatal("Failed to create bot", "error", err)
    }

    // --- ثبت Middleware ها ---
    bot.Use(
        middleware.Recovery(appLogger),
        middleware.Logging(appLogger),
        profanityInstance.Middleware(), // فیلتر کلمات
    )

    // --- هندلرها ---
    bot.OnCommand("start", func(ctx context.Context, msg *models.Message) {
        _, _ = bot.SendHTML(ctx, msg.Chat.ID, "سلام! ربات فیلتر کلمات فعال است.\nبرای تست، کلمات بد بفرست تا ببینی چطور پاک می‌شوند!")
    })

    // اگر پیام مشکلی نداشت، آن را به کاربر برمی‌گردانیم
    bot.OnMessage(func(ctx context.Context, msg *models.Message) {
        _, _ = bot.Send(ctx, msg.Chat.ID, "✅ پیام شما تمیز است: "+msg.Text)
    })

    // --- راه‌اندازی داشبورد و Polling ---
    go func() {
        appLogger.Info("Starting Web Dashboard on http://localhost:8081")
        if err := bot.StartDashboard(ctx, ":8081"); err != nil {
            appLogger.Error("Dashboard failed", "error", err)
        }
    }()

    pollingCfg := polling.DefaultConfig()
    pollingCfg.Timeout = 20

    appLogger.Info("Bot is starting polling...")
    if err := bot.StartPolling(ctx, pollingCfg); err != nil && err != context.Canceled {
        appLogger.Error("Bot stopped with error", "error", err)
    }

    appLogger.Info("Shutting down bot gracefully...")
    if err := bot.Close(); err != nil {
        appLogger.Error("Error during bot close", "error", err)
    }
}